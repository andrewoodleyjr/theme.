<ul class="currl-networks" data-position="text">
	<li class="currl-social"><a class="currl-social-link" target="_blank" title="copyright">&copy; 2014&ndash;<script>document.write(new Date().getFullYear())</script></a></li>
</ul>
</div>
</section>
</main>

<?php wp_footer(); ?>
</body>
</html>