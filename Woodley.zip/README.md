# Woodley Wordpress Theme
Minimalistic Wordpress Theme

Version: 1.0

![woodley theme](https://raw.githubusercontent.com/andrewoodleyjr/Woodley-Wordpress-Theme/master/screenshot-small.png)

### Installation
1. One of the following
   1. Upload the "Woodley" folder to the "/wp-content/themes/" directory
   2. find in Appearance > Themes > Install theme, type “Woodley” in search field.
2. Activate the Theme through the 'Themes' menu in WordPress
3. Go to "Appearance" > Theme options
4. Config theme as you need.
 
### Copyright
Distributed under the GPLv2 license http://www.gnu.org/licenses/gpl-2.0.html
